[Setup]
AppName=Content Blocker Pro
AppVersion=1.0.0
DefaultDirName={commonpf64}\ContentBlockerPro
DefaultGroupName=Content Blocker Pro
OutputBaseFilename=ContentBlockerPro_Installer
Compression=lzma
SolidCompression=yes
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=commandline
UninstallDisplayIcon={app}\ContentBlockerPro.exe
AppId=ContentBlockerPro
CreateAppDir=yes
AppPublisher=Content Blocker Pro
AppPublisherURL=https://example.com
AppSupportURL=https://example.com
AppUpdatesURL=https://example.com
ShowLanguageDialog=no

[Files]
Source: "C:\Users\Suleman Ozair\OneDrive\Desktop\python_basics\dist\ContentBlockerPro.exe"; DestDir: "{app}"

[Icons]
Name: "{group}\Content Blocker Pro"; Filename: "{app}\ContentBlockerPro.exe"
Name: "{commondesktop}\Content Blocker Pro"; Filename: "{app}\ContentBlockerPro.exe"

[Run]
Filename: "{app}\ContentBlockerPro.exe"; Description: "Launch Content Blocker Pro"; Flags: postinstall nowait
