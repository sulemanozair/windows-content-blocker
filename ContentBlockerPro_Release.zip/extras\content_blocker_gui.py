import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path
import ctypes
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog


class ContentBlockerApp:
    DEFAULT_PASSWORD = "ChangeMe123!"

    def __init__(self, root):
        self.root = root
        self.root.title("Content Blocker Pro")
        self.root.geometry("900x620")
        self.root.minsize(800, 520)
        self.root.configure(bg="#0b1120")

        self.hosts_path = Path(r"C:\Windows\System32\drivers\etc\hosts")
        self.blocked_domains_path = self._resolve_data_file("blocked_domains.json")
        self.settings_path = self._resolve_data_file("content_blocker_config.json")

        self.blocked_domains = []
        self.keywords = []
        self.admin_password = self.DEFAULT_PASSWORD
        self.status_var = tk.StringVar(value="Loading configuration...")
        self.password_var = tk.StringVar()

        self._load_settings()
        self._load_config()
        self._build_ui()
        self._refresh_status()

    def _resolve_data_file(self, file_name):
        if hasattr(sys, "_MEIPASS"):
            return Path(sys._MEIPASS) / file_name
        return Path(__file__).resolve().parent / file_name

    def _load_settings(self):
        try:
            if self.settings_path.exists():
                with open(self.settings_path, "r", encoding="utf-8") as file:
                    settings = json.load(file)
                self.admin_password = settings.get("admin_password", self.DEFAULT_PASSWORD)
            else:
                self.admin_password = self.DEFAULT_PASSWORD
                self._save_settings()
        except Exception:
            self.admin_password = self.DEFAULT_PASSWORD
            self._save_settings()
        self.password_var.set(self.admin_password)

    def _save_settings(self):
        with open(self.settings_path, "w", encoding="utf-8") as file:
            json.dump({"admin_password": self.admin_password}, file, indent=2)

    def _load_config(self):
        try:
            with open(self.blocked_domains_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            self.blocked_domains = data.get("blocked_domains", [])
            self.keywords = data.get("keywords_to_block", [])
        except Exception as exc:
            self.blocked_domains = []
            self.keywords = []
            messagebox.showerror("Config Error", f"Could not load blocked_domains.json: {exc}")

    def _set_status(self, message, success=True):
        self.status_var.set(message)
        if hasattr(self, "status_label"):
            self.status_label.config(fg="#86efac" if success else "#fca5a5")

    def _build_ui(self):
        self.root.grid_columnconfigure(0, weight=1)

        header = tk.Frame(self.root, bg="#0b1120")
        header.pack(fill="x", padx=22, pady=(20, 12))

        title = tk.Label(
            header,
            text="Content Blocker Pro",
            font=("Segoe UI", 26, "bold"),
            fg="#f8fafc",
            bg="#0b1120"
        )
        title.pack(anchor="w")

        subtitle = tk.Label(
            header,
            text="Secure Windows protection with a custom admin password",
            font=("Segoe UI", 11),
            fg="#cbd5e1",
            bg="#0b1120"
        )
        subtitle.pack(anchor="w", pady=(6, 0))

        main_card = tk.Frame(self.root, bg="#111827", padx=20, pady=20)
        main_card.pack(fill="both", expand=True, padx=22, pady=(0, 18))

        self.status_label = tk.Label(
            main_card,
            textvariable=self.status_var,
            font=("Segoe UI", 11, "bold"),
            fg="#86efac",
            bg="#111827",
            justify="left",
            wraplength=760,
            anchor="w"
        )
        self.status_label.pack(anchor="w", fill="x", pady=(0, 18))

        button_frame = tk.Frame(main_card, bg="#111827")
        button_frame.pack(fill="x")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Action.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 8))
        style.map("Action.TButton", background=[("active", "#2563eb")], foreground=[("active", "#ffffff")])

        self.enable_btn = ttk.Button(button_frame, text="Enable Blocker", command=self.enable_blocking, style="Action.TButton")
        self.enable_btn.pack(side="left", padx=(0, 10), pady=8)

        self.disable_btn = ttk.Button(button_frame, text="Disable Blocker", command=self.disable_blocking)
        self.disable_btn.pack(side="left", padx=(0, 10), pady=8)

        self.password_btn = ttk.Button(button_frame, text="Set Password", command=self.update_password)
        self.password_btn.pack(side="left", padx=(0, 10), pady=8)

        self.custom_btn = ttk.Button(button_frame, text="Add Custom Domain", command=self.add_custom_domain)
        self.custom_btn.pack(side="left", padx=(0, 10), pady=8)

        self.preview_btn = ttk.Button(button_frame, text="Preview Blocklist", command=self.preview_blocklist)
        self.preview_btn.pack(side="left", pady=8)

        password_frame = tk.Frame(main_card, bg="#111827")
        password_frame.pack(fill="x", pady=(18, 12))

        tk.Label(password_frame, text="Admin password:", fg="#e2e8f0", bg="#111827", font=("Segoe UI", 10, "bold")).pack(side="left")
        password_entry = tk.Entry(password_frame, textvariable=self.password_var, show="*", width=34, font=("Segoe UI", 10), bg="#0f172a", fg="#f8fafc", insertbackground="#f8fafc")
        password_entry.pack(side="left", padx=(10, 0))

        self.info_box = tk.Text(
            self.root,
            height=16,
            bg="#020817",
            fg="#dbeafe",
            font=("Consolas", 10),
            relief="flat",
            wrap="word",
            padx=12,
            pady=12
        )
        self.info_box.pack(fill="both", expand=True, padx=22, pady=(0, 14))
        self.info_box.insert("end", "Welcome.\n")
        self.info_box.insert("end", "- This app blocks known domains and keyword-based variations.\n")
        self.info_box.insert("end", "- Administrator access is required to modify the Windows hosts file.\n")
        self.info_box.insert("end", "- Use the Set Password button to choose your personal unlock password.\n")
        self.info_box.configure(state="disabled")

    def _refresh_status(self):
        active = self._is_blocker_active()
        if active:
            self._set_status("Status: ACTIVE - blocker is currently enabled", True)
            self.enable_btn.config(text="Re-enable Blocker")
        else:
            self._set_status("Status: INACTIVE - blocker is currently disabled", True)
            self.enable_btn.config(text="Enable Blocker")

    def _is_admin(self):
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            return False

    def _request_admin(self):
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None,
                "runas",
                sys.executable,
                "",
                None,
                1,
            )
            self.root.destroy()
        except Exception as exc:
            messagebox.showerror("Administrator Required", f"This app needs administrator rights. Error: {exc}")

    def _is_blocker_active(self):
        try:
            content = self.hosts_path.read_text(encoding="utf-8", errors="ignore")
            return "CONTENT BLOCKER (AI CONTROLLED)" in content
        except Exception:
            return False

    def _flush_dns(self):
        try:
            subprocess.run(["ipconfig", "/flushdns"], check=False, capture_output=True, text=True)
        except Exception:
            pass

    def enable_blocking(self):
        if not self._is_admin():
            self._request_admin()
            return

        try:
            content = self.hosts_path.read_text(encoding="utf-8", errors="ignore")
            backup_path = Path(str(self.hosts_path) + ".backup")
            if not backup_path.exists():
                backup_path.write_text(content, encoding="utf-8")

            blocklist = []
            for domain in self.blocked_domains:
                if domain not in content:
                    blocklist.append(domain)

            if blocklist:
                with open(self.hosts_path, "a", encoding="utf-8") as hosts_file:
                    hosts_file.write("\n# ===== CONTENT BLOCKER (AI CONTROLLED) =====\n")
                    hosts_file.write(f"# Enabled: {datetime.now().isoformat()}\n")
                    hosts_file.write(f"# Total domains: {len(self.blocked_domains)}\n")
                    for domain in blocklist:
                        hosts_file.write(f"127.0.0.1 {domain}\n")
                        hosts_file.write(f"0.0.0.0 {domain}\n")
                    hosts_file.write("# ===== END CONTENT BLOCKER =====\n")

            self._flush_dns()
            self._set_status(f"Status: ACTIVE - {len(self.blocked_domains)} domains are blocked", True)
            self.info_box.configure(state="normal")
            self.info_box.delete("1.0", "end")
            self.info_box.insert("end", "Blocker enabled successfully.\n")
            self.info_box.insert("end", f"- Domains loaded: {len(self.blocked_domains)}\n")
            self.info_box.insert("end", f"- Keyword filters loaded: {len(self.keywords)}\n")
            self.info_box.insert("end", "- DNS cache flushed\n")
            self.info_box.insert("end", "- Restart the browser to ensure all sites are blocked\n")
            self.info_box.configure(state="disabled")
            messagebox.showinfo("Blocked", "The blocker has been enabled successfully.")
        except Exception as exc:
            messagebox.showerror("Enable Error", f"Unable to enable blocker: {exc}")

    def disable_blocking(self):
        if not self._is_admin():
            self._request_admin()
            return

        entered = self.password_var.get().strip()
        if entered != self.admin_password:
            messagebox.showerror("Access Denied", "Incorrect password.")
            self._set_status("Status: Access denied", False)
            return

        try:
            with open(self.hosts_path, "r", encoding="utf-8", errors="ignore") as hosts_file:
                lines = hosts_file.readlines()

            filtered = []
            in_block_section = False
            for line in lines:
                if "===== CONTENT BLOCKER" in line or "===== END CONTENT BLOCKER" in line:
                    in_block_section = not in_block_section
                    continue
                if not in_block_section:
                    filtered.append(line)

            with open(self.hosts_path, "w", encoding="utf-8") as hosts_file:
                hosts_file.writelines(filtered)

            self._flush_dns()
            self._set_status("Status: INACTIVE - blocker has been removed", True)
            self.info_box.configure(state="normal")
            self.info_box.delete("1.0", "end")
            self.info_box.insert("end", "Blocker disabled successfully.\n")
            self.info_box.configure(state="disabled")
            messagebox.showinfo("Disabled", "The blocker has been disabled.")
        except Exception as exc:
            messagebox.showerror("Disable Error", f"Unable to disable blocker: {exc}")

    def update_password(self):
        new_password = simpledialog.askstring("Set new password", "Choose a password to unlock the blocker:", show="*")
        if new_password is None:
            return
        new_password = new_password.strip()
        if len(new_password) < 4:
            messagebox.showerror("Invalid Password", "Password must be at least 4 characters long.")
            return

        confirm = simpledialog.askstring("Confirm password", "Re-enter your new password:", show="*")
        if confirm is None or confirm.strip() != new_password:
            messagebox.showerror("Password Mismatch", "The passwords do not match.")
            return

        self.admin_password = new_password
        self.password_var.set(new_password)
        self._save_settings()
        self._set_status("Status: password updated successfully", True)
        messagebox.showinfo("Password Updated", "Your admin password has been saved.")

    def add_custom_domain(self):
        domain = simpledialog.askstring("Add Domain", "Enter a domain to block\nExample: example.com")
        if not domain:
            return
        domain = domain.strip().lower()
        if not domain:
            return

        if domain not in self.blocked_domains:
            self.blocked_domains.append(domain)
            self.blocked_domains.append(f"www.{domain}")
            try:
                with open(self.blocked_domains_path, "w", encoding="utf-8") as file:
                    json.dump({"blocked_domains": self.blocked_domains, "keywords_to_block": self.keywords}, file, indent=2)
                messagebox.showinfo("Saved", f"{domain} was added to the block list.")
            except Exception as exc:
                messagebox.showerror("Save Error", f"Could not save custom domain: {exc}")
        else:
            messagebox.showinfo("Duplicate", "That domain is already blocked.")

    def preview_blocklist(self):
        preview_window = tk.Toplevel(self.root)
        preview_window.title("Blocked Domains Preview")
        preview_window.geometry("520x420")
        preview_window.configure(bg="#0f172a")

        text_widget = tk.Text(preview_window, wrap="word", font=("Consolas", 10), bg="#020817", fg="#dbeafe")
        text_widget.pack(fill="both", expand=True, padx=10, pady=10)

        sample = self.blocked_domains[:120]
        text_widget.insert("end", "\n".join(sample))
        text_widget.configure(state="disabled")


def main():
    if not ctypes.windll.shell32.IsUserAnAdmin():
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None,
                "runas",
                sys.executable,
                "",
                None,
                1,
            )
            return
        except Exception:
            messagebox.showerror("Administrator Required", "This app must be run as Administrator to modify the Windows hosts file.")
            return

    root = tk.Tk()
    app = ContentBlockerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
