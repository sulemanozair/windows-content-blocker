Content Blocker Pro

This package is the final publish-ready release.

Included files:
- ContentBlockerPro.exe
- ContentBlockerPro_Installer.exe
- blocked_domains.json
- app_icon.ico
- app_icon.png

How to install:
1. Run ContentBlockerPro_Installer.exe as Administrator.
2. Follow the setup wizard.
3. Launch the app from the Start menu or desktop shortcut.

Important:
- The app requires administrator rights to modify the Windows hosts file.
- The blocked_domains.json file must remain next to the app or in the installed app directory.
- The app allows the user to set a custom password from inside the app.

For a clean distribution:
- Share the ZIP package or installer file directly.
- Do not rename or remove blocked_domains.json.
